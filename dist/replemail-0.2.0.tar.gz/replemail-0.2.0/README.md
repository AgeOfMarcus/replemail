# replemail
API wrapper for https://repl.email

### [Get your API key here](https://repl.email/settings)